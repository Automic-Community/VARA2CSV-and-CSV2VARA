CSV2VARA / VARA2CSV by Joel Wiesmann (joel.wiesmann at gmail.com)

Prerequisites
=============

Requires AE 10+. Please notice, that AE 11+ multiline VARA content does not work (yet). You can export on any OS agent - tested was Unix and Windows.

Installation
============

1. Import the XML (whereever you want)
2. Register the objects in the UC_SENDTO VARA (if not available, have a chat with your AE admin, the VARA will be on client 0).

Example (Key/Value1):
CSV2VARA	CSV2VARA#SCRI_SENDTO				
VARA2CSV	VARA2CSV#SCRI_SENDTO				

3. Restart your AE client. 

Export a VARA to a CSV file
===========================

1. Right-click on any VARA objects, choose "send to", "VARA2CSV"
2. A promptset will popup. Enter your agent & appropriate path/file & delimiter information
3. Press OK
=> a second later the CSV file will be there

Import a CSV to a VARA
======================

1. Right-click on any VARA objects, choose "send to", CSV2VARA"
2. A promptset will popup. Enter your agent & appropriate path/file & delimiter information
3. If necessary, you can choose to skip the header or clear the VARA content first
4. Press OK
=> a seconds later the CSV is loaded into the VARA

Tuning & hints
==============

* If you tend to export your files to the same location, you can preconfigure the values by editing the PRPT. 
* For the VARA2CSV you can enter [VARA] in the destination filename (like C:\temp\[VARA]_&$LDATE_YYYYMMDD#.csv),
  the [VARA] will be replaced by the VARA name.
* If you can enter values for all MUST fields, edit the SENDTO SCRI and set the &L_INTERACTIVE# variable to "N",
  that way no prompt will popup at all.
* You can also select multiple VARAs and export them at once. Especially if you have default values & the 
  &L_INTERACTIVE# set to N you can batch-export many VARAs at once.
* You can also append multiple VARAs to the same file by using the APPEND mode.

Have fun :)!